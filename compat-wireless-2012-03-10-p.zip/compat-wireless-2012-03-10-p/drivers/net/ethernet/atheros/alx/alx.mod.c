#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

MODULE_INFO(vermagic, VERMAGIC_STRING);

struct module __this_module
__attribute__((section(".gnu.linkonce.this_module"))) = {
 .name = KBUILD_MODNAME,
 .init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
 .exit = cleanup_module,
#endif
 .arch = MODULE_ARCH_INIT,
};

static const struct modversion_info ____versions[]
__used
__attribute__((section("__versions"))) = {
	{ 0x35746b77, "module_layout" },
	{ 0xfaf98462, "bitrev32" },
	{ 0xa34f1ef5, "crc32_le" },
	{ 0x21fb443e, "_raw_spin_lock_irqsave" },
	{ 0xfb82de7c, "ethtool_op_get_link" },
	{ 0x73e20c1c, "strlcpy" },
	{ 0x44b87ef7, "kmem_cache_alloc_trace" },
	{ 0x153b1ca8, "kmalloc_caches" },
	{ 0x8c68e30b, "eth_validate_addr" },
	{ 0x437b4a45, "pci_unregister_driver" },
	{ 0xb0d20bb2, "__pci_register_driver" },
	{ 0xe0d81039, "compat_dependency_symbol" },
	{ 0x3cd284aa, "netif_carrier_on" },
	{ 0xbd5aa7b7, "netdev_update_features" },
	{ 0x41fa6cb4, "__netdev_printk" },
	{ 0x76cf3e4f, "pci_bus_write_config_word" },
	{ 0xfb0e29f, "init_timer_key" },
	{ 0xd4a5c5c, "register_netdev" },
	{ 0xe914e41e, "strcpy" },
	{ 0xb29b3246, "netif_napi_add" },
	{ 0xd082333b, "pci_enable_msi_block" },
	{ 0x1c603f23, "pci_enable_msix" },
	{ 0x79aa04a2, "get_random_bytes" },
	{ 0x2d37342e, "cpu_online_mask" },
	{ 0xb6ed1e53, "strncpy" },
	{ 0x42c8de35, "ioremap_nocache" },
	{ 0x40a4ed3b, "dev_set_drvdata" },
	{ 0x6c6dbc50, "alloc_etherdev_mqs" },
	{ 0x3d3373eb, "pci_enable_pcie_error_reporting" },
	{ 0xf91ff0d8, "pci_request_selected_regions" },
	{ 0x54c9f16b, "_dev_info" },
	{ 0x1090dfe3, "dma_supported" },
	{ 0x8a093a7f, "dma_set_mask" },
	{ 0xf23977e5, "pci_enable_device_mem" },
	{ 0xcb98ee85, "pci_bus_read_config_word" },
	{ 0x93c190c6, "x86_dma_fallback_dev" },
	{ 0x9a35a62f, "dma_alloc_from_coherent" },
	{ 0x8608cd80, "pci_prepare_to_sleep" },
	{ 0xb1e1fdaa, "pci_wake_from_d3" },
	{ 0x1dfcbecc, "device_set_wakeup_enable" },
	{ 0xeae3dfd6, "__const_udelay" },
	{ 0x817b4f8c, "netif_device_detach" },
	{ 0xd5f2172f, "del_timer_sync" },
	{ 0xf9a482f9, "msleep" },
	{ 0x799aca4, "local_bh_enable" },
	{ 0x76ebea8, "pv_lock_ops" },
	{ 0x67f7403e, "_raw_spin_lock" },
	{ 0x47c7b0d2, "cpu_number" },
	{ 0x3ff62317, "local_bh_disable" },
	{ 0xeb2dd198, "netif_carrier_off" },
	{ 0x3d56fdc5, "netif_device_attach" },
	{ 0xf3a2d71a, "pci_save_state" },
	{ 0x8188d99a, "pci_restore_state" },
	{ 0x4c8e7607, "pci_set_power_state" },
	{ 0xf20dabd8, "free_irq" },
	{ 0xa0208e02, "irq_set_affinity_hint" },
	{ 0x91715312, "sprintf" },
	{ 0x2072ee9b, "request_threaded_irq" },
	{ 0x7f5f2c64, "dev_err" },
	{ 0x16305289, "warn_slowpath_null" },
	{ 0x47458500, "___pskb_trim" },
	{ 0x42164fd2, "page_address" },
	{ 0x47263442, "dev_warn" },
	{ 0x9f385f6e, "pskb_expand_head" },
	{ 0xf97456ea, "_raw_spin_unlock_irqrestore" },
	{ 0x5383f34b, "_raw_spin_trylock" },
	{ 0x8ff4079b, "pv_irq_ops" },
	{ 0xdf198692, "napi_complete" },
	{ 0x26d6779a, "netif_receive_skb" },
	{ 0xa02bb4c3, "eth_type_trans" },
	{ 0x4bf0da38, "skb_put" },
	{ 0x6c62f67f, "dma_release_from_coherent" },
	{ 0xb7014477, "dev_kfree_skb_any" },
	{ 0x5b8bd4b8, "mem_map" },
	{ 0xe0cae27, "dev_alloc_skb" },
	{ 0x12da5bb2, "__kmalloc" },
	{ 0xf12b159b, "__netif_schedule" },
	{ 0x35f2438c, "dev_kfree_skb_irq" },
	{ 0x502c8e81, "pci_disable_device" },
	{ 0x89ca697a, "pci_disable_pcie_error_reporting" },
	{ 0xc6a3f8e3, "free_netdev" },
	{ 0x60c57746, "pci_release_selected_regions" },
	{ 0x79ea1b2a, "pci_select_bars" },
	{ 0xedc03953, "iounmap" },
	{ 0xb508b3f5, "netif_napi_del" },
	{ 0x130f8dae, "unregister_netdev" },
	{ 0x4205ad24, "cancel_work_sync" },
	{ 0xc2ac1d84, "pci_disable_msi" },
	{ 0xab87dce3, "pci_disable_msix" },
	{ 0x427be022, "netdev_warn" },
	{ 0x8834396c, "mod_timer" },
	{ 0x7d11c268, "jiffies" },
	{ 0x8949858b, "schedule_work" },
	{ 0x2bc95bd4, "memset" },
	{ 0x31a7f4b2, "dma_ops" },
	{ 0x890c8c0e, "consume_skb" },
	{ 0xe523ad75, "synchronize_irq" },
	{ 0x2e60bace, "memcpy" },
	{ 0xf84d9ccf, "netdev_err" },
	{ 0x46e0a944, "pci_cleanup_aer_uncorrect_error_status" },
	{ 0xe1e8e8e3, "__pci_enable_wake" },
	{ 0x951ada2b, "pci_set_master" },
	{ 0x2c821dc6, "pci_enable_device" },
	{ 0x7fdbc34b, "dev_get_drvdata" },
	{ 0x74c134b9, "__sw_hweight32" },
	{ 0x965b56aa, "netdev_info" },
	{ 0x68903178, "__napi_schedule" },
	{ 0x50eedeb8, "printk" },
	{ 0x37a0cba, "kfree" },
	{ 0xb4390f9a, "mcount" },
};

static const char __module_depends[]
__used
__attribute__((section(".modinfo"))) =
"depends=compat";

MODULE_ALIAS("pci:v00001969d00001063sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00001969d00001062sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00001969d00001073sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00001969d00001083sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00001969d00002060sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00001969d00002062sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00001969d00001091sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00001969d00001090sv*sd*bc*sc*i*");

MODULE_INFO(srcversion, "14D5C939B47488F23252A79");
